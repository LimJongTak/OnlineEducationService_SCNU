const form = document.querySelector('form');
form.addEventListener('submit', (event) => {
	event.preventDefault();
	const username = document.getElementById('username').value;
	const password = document.getElementById('password').value;
	if (username === '' || password === '') {
		alert('Please enter your username and password.');
	} else {
		// 로그인 처리 코드 작성
		alert(`Welcome, ${username}!`);
		window.location.href = "web.html"; // 웹 페이지 이동
	}
});
